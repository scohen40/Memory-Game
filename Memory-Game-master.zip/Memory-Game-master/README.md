# Memory-Game
A simple memory picture card game.

**TO DO**
***
* Game/Guess Algorithm Tests Class
* Game main.GUI Tests Class

**BOARD REQUIREMENTS**
***
* The highest number of Rows and Columns is 6, or the number of card names and icons must be raised.
* Either the number of Rows or Columns must be even so that the number of Matches is a whole number.

**OPTIONAL TO DO**
***
* Multiplayer Game Class 
* Easy, Medium, and Hard Levels 
