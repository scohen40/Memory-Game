package board;

public class Properties {
    private static int totalWins;

    public static int getTotalWins() {
        return totalWins;
    }
}
